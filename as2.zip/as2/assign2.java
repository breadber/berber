import java.io.*;
import java.util.*;
public class assign2
{
    public static String Insert(String Origin, char put, int index){
        index = limit(index, Origin.length() - 1);
        return (Origin.substring(0,index) + put + Origin.substring(index));
    }
    public static String Change(String Origin, char put, int index){
        index = limit(index, Origin.length());
        return (Origin.substring(0,index) + put + Origin.substring(index + 1));
    }
    public static String Remove(String Origin, int index){
        index = limit(index, Origin.length());
        return (Origin.substring(0,index) + Origin.substring(index + 1));
    }
    public static int limit(int input, int limit){
        if (input <= 0) return 0;
        if (input >= limit) return limit;
        return input;
    }
    public static char getChar(Scanner sca){
        System.out.println("Please enter the char:");
        return sca.next().toLowerCase().charAt(0);
    }
	public static void main(String[] args) {
		Scanner sca = new Scanner(System.in);
		System.out.println("Please enter the Dictionary file name:");
		Dictionary dict = new Dictionary(sca.next());
		Dictionary usedWords = new Dictionary();
		System.out.println("Welcome to word changer!");
		System.out.println("Here is how to play:");
		System.out.println("For each round you will see two randomly selected words.");
		System.out.println("You will have 1 minute to convert the first word to the second using only the following changes:");
		System.out.println("Insert a character at position k (with k starting at 0)\nDelete a character at position k (with k starting at 0)\nChange a character at position k (with k starting at 0)\nFor example, to change the word 'WEASEL' to 'SEASHELL' you could do the following:\n");
		System.out.println("1) Change 'W' at position 0 to 'S': SEASEL");
        System.out.println("2) Insert 'H' at position 4: SEASHEL");
        System.out.println("3) Insert 'L' at position 7: SEASHELL");
        System.out.println("Your goal is to make this conversion with the fewest changes.");
        System.out.println("Note that there may be more than one way to achieve this goal.");
        GamePlayer Player = new GamePlayer();
        MyTimer Timer = new MyTimer(60000);
        System.out.println("Now let's Welcome Mr./Ms." + Player.getName() + " !");
        while (true){
            System.out.println("Would you want to try? Enter Y as yes and N as No:");
            char Option = sca.next().toLowerCase().charAt(0);
            if (Option == 'n') System.exit(0);
            if (Option == 'y'){
                if (usedWords.toString().length() >= dict.toString().length()){
                    System.out.println("We have used all the words!");
                    System.exit(0);
                }
                String WordOne = "";
                String WordTwo = "";
                do{
                    WordOne = dict.randWord(5,10);
                }
                while (usedWords.contains(WordOne));
                do{
                    WordTwo = dict.randWord(5,10);
                }
                while (usedWords.contains(WordTwo));
                int Distance = Dictionary.distance(WordOne, WordTwo);
                System.out.println("Your goal is to convert '" + WordOne + "' to '" + WordTwo + "' in " + Distance + " edits!");
                int tries = 0;
                Timer.start();
                do{
                    if (!Timer.check()){
                        System.out.println("Sorry, time expired!");
                        break;
                    }
                    System.out.println("Index\t\t0123456789");
                    System.out.println("-----\t\t----------");
                    System.out.println("Current Word:\t" + WordOne);
                    System.out.println("Word 2:\t\t" + WordTwo);
                    System.out.println("Here are your options:");
                    System.out.println("\tC k v -- Change char at location k to value v");
                    System.out.println("\tI k v -- Insert char at location k with value v");
                    System.out.println("\tD k   -- Delete char at location k");
                    System.out.println("Option choice > ");
                    char action = sca.next().toLowerCase().charAt(0);
                    System.out.println("Please enter your index:");
                    int index = sca.nextInt();
                    switch(action){
                        case 'i': WordOne = Insert(WordOne, getChar(sca), index);
                        break;
                        case 'c': WordOne = Change(WordOne, getChar(sca), index);
                        break;
                        case 'd': WordOne = Remove(WordOne, index);
                        break;
                        default: System.out.println("Not valid input");
                        break;
                    }
                    tries++;
                }
                while (!WordOne.equalsIgnoreCase(WordTwo));
                if (WordOne.equalsIgnoreCase(WordTwo)){
                    System.out.println("You win!");
                    Player.success(tries, Distance);
                }
                else {
                    System.out.println("You lose!");
                    Player.failure();
                }
                System.out.println(Player);
                Player.writeFile();
            }
        }
	}
}