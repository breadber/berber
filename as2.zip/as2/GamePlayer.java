import java.io.*;
import java.util.*;

public class GamePlayer {
    private String Name;
    private int Rounds_Total;
    private int Rounds_Failure;
    private int Rounds_Success;
    private int Tries_Player;
    private int Tries_Optimal;
    private String Passcode;
    private File Data;
    
    public GamePlayer(){
        this(null);
    }
    
    public GamePlayer(String Name){
        this(Name, 0, 0, 0, 0);
        if (Data.exists()) {
            readFile();
            login();
        }
        else register();
    }
    
    public GamePlayer(String Name, int Rounds_Total, int Rounds_Success, int Tries_Optimal, int Tries_Player){
        this.Name = Name;
        this.Rounds_Total = Rounds_Total;
        this.Rounds_Success = Rounds_Success;
        this.Rounds_Failure = Rounds_Total - Rounds_Success;
        this.Tries_Optimal = Tries_Optimal;
        this.Tries_Player = Tries_Player;
        this.Data = new File(Name + ".txt");
    }
    
    public String getSuccessRatio(){
        double ratio = (double)Tries_Player / (double)Tries_Optimal;
        return ("" + ratio);
    }
    
    public String getName(){
        return this.Name;
    }
    
    public String getPasscode(){
        return this.Passcode;
    }
    
    public String toString(){
        return ("Player Status:\n" + 
        "Name: " + Name + "\n" +
        "Total rounds: " + Rounds_Total + "\n" +
        "Failure rounds: " + Rounds_Failure + "\n" +
        "Success rounds: " + Rounds_Success + "\n" +
        "Success ratio: " + getSuccessRatio() + "\n\n");
    }
    
    public String toStringFile(){
        return (Rounds_Total + "\n" + Rounds_Success + "\n" + Tries_Optimal + "\n" + Tries_Player + "\n" + Passcode + "\n");
    }
    
    public void success(int Tries_Player, int Tries_Optimal){
        Rounds_Success++;
        Rounds_Total++;
        this.Tries_Optimal += Tries_Optimal;
        this.Tries_Player += Tries_Player;
    }
    
    public void failure(){
        Rounds_Total++;
    }
    
    private void initialize(){
        this.Rounds_Total = 0;
        this.Rounds_Success = 0;
        this.Rounds_Failure = 0;
        this.Tries_Optimal = 0;
        this.Tries_Player = 0;
    }
    
    public void readFile(){
        try {
            if (!Data.exists()) return;
            Scanner inFile = new Scanner(Data);
            this.Rounds_Total = inFile.nextInt();
            this.Rounds_Success = inFile.nextInt();
            this.Rounds_Failure = Rounds_Total - Rounds_Success;
            this.Tries_Optimal = inFile.nextInt();
            this.Tries_Player = inFile.nextInt();
            this.Passcode = inFile.next();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }
    
    public void writeFile(){
        try {
            if (!Data.exists()) Data.createNewFile();
            PrintWriter OutPut = new PrintWriter(Data);
            OutPut.write(toStringFile());
            OutPut.close();
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
    
    public void login(){
        Scanner inPut = new Scanner(System.in);
        System.out.println("Dear Mr./Ms. " + Name + ", please enter your Passcode, enter reg to register:");
        String Temp_Passcode = inPut.next();
        if (Temp_Passcode.equals("reg")){
            System.out.println("Now direct you to register!");
            register();
            return;
        }
        if (Temp_Passcode.equals(Passcode)){
            System.out.println("Successfully login!");
            return;
        }
        System.out.println("Wrong Passcode! Please try again!");
        login();
    }
    
    public void register(){
        initialize();
        Scanner inPut = new Scanner(System.in);
        System.out.println("Please enter your name:");
        this.Name = inPut.next();
        this.Data = new File(Name + ".txt");
        if (Data.exists()){
            readFile();
            System.out.println("Name exist, not direct to login!");
            login();
            return;
        }
        if (this.Name.equals("reg")){
            System.out.println("You can't set your name as reg!");
            register();
            return;
        }
        System.out.println("Please enter your Passcode:");
        this.Passcode = inPut.next();
        writeFile();
    }
}